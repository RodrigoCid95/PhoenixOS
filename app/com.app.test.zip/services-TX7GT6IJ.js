var t=class extends window.Service{async getLocation(){return await(await this.getDriver("geolocation")).getCurrentPosition()}onKill(){console.log("onKill",this)}};export{t as default};
